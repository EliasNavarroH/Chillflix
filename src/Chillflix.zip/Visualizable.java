public interface Visualizable {
    public int tiempoVisto();
    public int ponerCalificacion();
}
